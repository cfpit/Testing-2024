package inicio;

public class CajaDeAhorro {
    //atributos
    public int saldo;
    public String moneda;
    
    //constructor
    public CajaDeAhorro() {}
    
    
    //metodos
    public void depositar(int monto) {
        saldo = saldo + monto;
    }
}
