

package inicio;


public class Test {
    public static void main(String[] args) {
        //creo un objeto de la clase CajaDeAhorro
        CajaDeAhorro cda = new CajaDeAhorro();
        
        //le asigno un estado al objeto
        cda.saldo = 5000;
        cda.moneda = "U$s";
        
        //comportamiento
        cda.depositar(1500);
        
        //muestro el saldo en la consola de salida
        System.out.println("saldo = " + cda.saldo);//6500

    }

    
}
