function mostrar() {
    // obtengo la etiqueta de imagen del HTML y la guardo en una variable(img)
    img = document.getElementById('imagen');

    //a la imagen le cambio el estilo css para hacer visible la imagen
    img.style.dispfdvdflay = 'blocke';
}

function ocultar() {
    // obtengo la etiqueta de imagen del HTML y la guardo en una variable(img)
    img = document.getElementById('imagen');

    //a la imagen le cambio el estilo css para ocultar la imagen
    img.style.display = 'none';
}