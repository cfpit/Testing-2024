/*
    @BeforeClass
    Esta anotación indica que el método anotado debe ejecutarse una sola vez antes 
    de que se ejecute cualquier método de prueba en la clase. Es decir, setUpClass() 
    se ejecuta una vez para toda la clase de prueba, independientemente de cuántos 
    métodos de prueba tenga. Este método es útil para configuraciones que deben 
    realizarse una sola vez, como la conexión a una base de datos o la carga de 
    recursos pesados.

    @AfterClass
    Similar a @BeforeClass, pero indica que el método anotado debe ejecutarse una 
    sola vez después de que todos los métodos de prueba en la clase hayan sido 
    ejecutados. tearDownClass() se utiliza para limpiar recursos que fueron establecidos 
    en setUpClass(), como cerrar conexiones a bases de datos o liberar memoria.

    @Before
    Esta anotación se utiliza para indicar que el método anotado debe ejecutarse 
    antes de cada método de prueba en la clase. setUp() se ejecuta antes de cada 
    prueba, lo que lo hace ideal para configuraciones que deben realizarse antes 
    de cada prueba individual, como reiniciar estados mutables o preparar datos 
    de prueba específicos.

    @After
    Indica que el método anotado debe ejecutarse después de cada método de prueba 
    en la clase. tearDown() se utiliza para limpiar después de cada prueba, 
    restableciendo el estado del sistema a su condición original o liberando recursos 
    que se utilizaron durante la prueba. Esto es crucial para evitar efectos 
    secundarios entre pruebas que puedan causar fallos en otras pruebas.
    
    
    Ejemplo: 
    
    @BeforeClass
    public static void setUpClass() {
        // Abre la conexión a la base de datos
    }

    @AfterClass
    public static void tearDownClass() {
        // Cierra la conexión a la base de datos
    }

    @Before
    public void setUp() {
        // Prepara datos específicos de prueba
    }

    @After
    public void tearDown() {
        // Limpia los datos de prueba
    }

    @Test
    public void testDatabaseOperation() {
        // Realiza la prueba
    }

    

*/
package pruebaUnitaria;

import org.junit.After;
import org.junit.AfterClass;
import org.junit.Before;
import org.junit.BeforeClass;
import org.junit.Test;
import static org.junit.Assert.*;
import prueba.Calculadora;

/**
 *
 * @author Notebook Dell
 */
public class CalculadoraPrueba {
    
    public CalculadoraPrueba() {
    }
    
//    @BeforeClass
//    public static void setUpClass() {
//    }
//    
//    @AfterClass
//    public static void tearDownClass() {
//    }
//    
//    @Before
//    public void setUp() {
//    }
//    
//    @After
//    public void tearDown() {
//    }

    
    
    
     @Test
    public void pruebaSumar() {
        Calculadora c = new Calculadora();
        int resultado = c.sumar(2, 3);
        assertEquals(5, resultado);
        assertTrue(resultado < 15);

    }

    
}
