/*
    1)Primero, creamos una clase de prueba para nuestra función de suma.
    
    2)Si intentamos ejecutar nuestra prueba, fallará porque la función sumar aún no 
    está definida.

    3)A continuación, definimos la función de suma más simple posible que haga 
    pasar nuestra prueba.

    4)Nuestra función sumar es simple, por lo que no hay necesidad de refactorización 
    sin cambiar su comportamiento. Sin embargo, podríamos considerar agregar validaciones 
    adicionales, como verificar que los parámetros sean enteros. Si decidimos agregar 
    estas características, debemos actualizar nuestras pruebas para reflejar estos 
    nuevos casos de uso.
*/

package pruebaTDD;

import org.junit.Test;
import static org.junit.Assert.*;

public class SumaTest {
    
    @Test
    public void testSum() {
        assertEquals("La suma de 1 y 2 debería ser 3", 3, sumar(1, 2));
    }
    
    
    
//Agrego funcion sumar para pasar la prueba   
    public int sumar(int a, int b) {
        return a + b;
    }
    
    
}
